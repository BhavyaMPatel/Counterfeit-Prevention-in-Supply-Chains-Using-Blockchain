import Web3 from 'web3';

// Paste your ABI here
export const contractABI = [
    // The ABI array goes here
];

export const contractAddress = '0xYourContractAddress'; // Replace with your actual contract address

const getWeb3 = () => {
    return new Web3(Web3.givenProvider || "http://localhost:7545");
};

export default getWeb3;
